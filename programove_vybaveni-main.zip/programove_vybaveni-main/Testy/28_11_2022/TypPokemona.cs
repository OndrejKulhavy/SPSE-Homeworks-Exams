public enum TypPokemona
{

    //ps: neznám pokémony😅
    Ocel,
    Voda,
    Ohnivy,
    Kamenny,
}