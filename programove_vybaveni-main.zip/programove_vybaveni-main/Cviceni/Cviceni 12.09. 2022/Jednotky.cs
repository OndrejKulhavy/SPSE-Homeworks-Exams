public enum Jednotky
{
    kcal, kJ
}