﻿using System;

namespace Cviceni_4
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
