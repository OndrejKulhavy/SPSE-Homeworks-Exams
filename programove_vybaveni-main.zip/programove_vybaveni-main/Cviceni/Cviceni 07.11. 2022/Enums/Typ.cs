namespace Cviceni_07._11._2022.Enums
{
    public enum Typ
    {
        DOMECEK_KARKULKY,
        DOMECEK_BABICKY,
        VYHLIDKA,
        KAMEN,
        PREZKAZKA,
        BLUDNY_KOREN,
        VLK,
        KVETINOVA_LOUKA
    }
}
