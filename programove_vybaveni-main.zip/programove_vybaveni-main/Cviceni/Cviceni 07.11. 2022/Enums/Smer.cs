namespace Cviceni_07._11._2022.Enums
{
    public enum Smer
    {
        VPRAVO,
        DOLU,
        VLEVO,
        NAHORU
    }
}