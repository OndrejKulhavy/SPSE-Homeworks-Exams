namespace Cviceni_12._12._2022
{
    public enum Pozice
    {
        Programator,
        Tester,
        Manager,
        CEO
    }
}
