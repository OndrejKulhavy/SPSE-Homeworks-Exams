public enum Uroven{
    INFORMACE,
    VAROVANI,
    CHYBA,
    ANY
}