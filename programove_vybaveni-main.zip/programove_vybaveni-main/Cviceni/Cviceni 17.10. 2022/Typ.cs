public enum Typ
{
    SYSTEMOVA,
    HARDWAROVA,
    APLIKACNI,
    ANY
}