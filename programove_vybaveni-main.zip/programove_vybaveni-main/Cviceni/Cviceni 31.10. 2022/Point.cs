namespace Cviceni_31._10._2022
{
    internal class Point
    {
        
    }
}