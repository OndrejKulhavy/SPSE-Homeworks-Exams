﻿using System;

namespace Cviceni_24._10._2022
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
