# Geography
Created: 07.01.2023 16:17:14
Number of items: 7
### 1. What is the capital of India?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
New Delhi
```
### 2. What is the highest mountain in the world?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
Mount Everest
```
### 3. What is the longest river in the world?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
Nile River
```
### 4. What is the largest ocean in the world?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
Pacific Ocean
```
### 5. What is the largest country in the world by land area?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
Russia
```
### 6. What is the currency of Japan?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
Yen
```
### 7. What is the capital of Brazil?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
Brasília
```
# History
Created: 07.01.2023 16:31:51
Number of items: 7
### 1. Who was president of the United States?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
George Washington
Donald Trump
```
### 2. Who was the leader of the Soviet Union during World War II?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
Joseph Stalin
```
### 3. Which of the following events occurred first?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
The signing of the Magna Carta
```
### 4. Which of the following wars took place first?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
World War I
```
### 5. Who was the first man to set foot on the moon?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
Neil Armstrong
```
### 6. Which of the following empires existed first?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
Mongol Empire
```
### 7. Who was the first king of England?

- {option}
- {option}
- {option}
- {option}

Correct answer(s):
```
William the Conqueror
```
