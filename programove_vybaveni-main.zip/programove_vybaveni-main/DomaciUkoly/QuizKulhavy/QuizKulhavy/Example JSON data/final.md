# Geography
## Created: 07.01.2023 16:17:14
## Number of items: 7
### 1. What is the capital of India?
- Mumbai
- New Delhi
- Chennai
- Kolkata

Correct answer(s):
```
New Delhi
```
### 2. What is the highest mountain in the world?

    - Lhotse
    - Kangchenjunga
    - Mount Everest
    - K2

Correct answer(s):
```
Mount Everest
```
### 3. What is the longest river in the world?

    - Yangtze River
    - Mississippi River
    - Nile River
    - Amazon River

Correct answer(s):
```
Nile River
```
### 4. What is the largest ocean in the world?

    - Atlantic Ocean
    - Arctic Ocean
    - Indian Ocean
    - Pacific Ocean

Correct answer(s):
```
Pacific Ocean
```
### 5. What is the largest country in the world by land area?

    - Canada
    - China
    - United States
    - Russia

Correct answer(s):
```
Russia
```
### 6. What is the currency of Japan?

    - Pound
    - Euro
    - Yen
    - Dollar

Correct answer(s):
```
Yen
```
### 7. What is the capital of Brazil?

    - São Paulo
    - Belo Horizonte
    - Brasília
    - Rio de Janeiro

Correct answer(s):
```
Brasília
```
# History
## Created: 07.01.2023 16:31:51
## Number of items: 7
### 1. Who was president of the United States?

    - Donald Trump
    - George Washington
    - Thomas Jefferson
    - John Quincy Adams

Correct answer(s):
```
George Washington
Donald Trump
```
### 2. Who was the leader of the Soviet Union during World War II?

    - Joseph Stalin
    - Nikita Khrushchev
    - Leon Trotsky
    - Mikhail Gorbachev

Correct answer(s):
```
Joseph Stalin
```
### 3. Which of the following events occurred first?

    - The signing of the Magna Carta
    - The discovery of America by Columbus
    - The fall of the Berlin Wall
    - The assassination of Julius Caesar

Correct answer(s):
```
The signing of the Magna Carta
```
### 4. Which of the following wars took place first?

    - World War I
    - World War II
    - Vietnam War
    - Korean War

Correct answer(s):
```
World War I
```
### 5. Who was the first man to set foot on the moon?

    - Neil Armstrong
    - Buzz Aldrin
    - Pete Conrad
    - Alan Bean

Correct answer(s):
```
Neil Armstrong
```
### 6. Which of the following empires existed first?

    - Roman Empire
    - British Empire
    - Mongol Empire
    - Ottoman Empire

Correct answer(s):
```
Mongol Empire
```
### 7. Who was the first king of England?

    - Henry VIII
    - Edward IV
    - George III
    - William the Conqueror

Correct answer(s):
```
William the Conqueror
```
