# Quiz App

## Features
- [ ] Export dataset to Markdown
- [ ] Save-load dataset to local storage as JSON
- [ ] Learning mode
    - [ ] Show question
    - [ ] Show answer
    - [ ] Show explanation

- [ ] Quiz mode
    - [ ] Show question
    - [ ] Check your answer
    - [ ] Show your score