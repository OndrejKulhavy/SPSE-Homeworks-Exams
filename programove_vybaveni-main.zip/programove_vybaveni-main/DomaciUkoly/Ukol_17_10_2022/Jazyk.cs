/*
 * Created Date: Wednesday, October 19th 2022, 12:17:27 pm
 * Author: Ondřej Kulhavý
 * 
 * Copyright (c) 2022
 */
using System;
using System.Collections.Generic;

namespace Ukol_17_10_2022
{
    public enum Jazyk
{
    cs,
    en
}
}
